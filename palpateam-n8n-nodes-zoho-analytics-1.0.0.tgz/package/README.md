# n8n-nodes-zoho-analytics

This is an n8n community node to interact with Zoho Analytics API v2.

## Installation

Follow the [installation guide](https://docs.n8n.io/integrations/community-nodes/installation/) in the n8n community nodes documentation.

```bash
npm install @palpateam/n8n-nodes-zoho-analytics
```

## Features

- **Row Operations**: Add, Update, Delete rows.
- **Data Operations**: Export and Import data (JSON supported).
- **Table Operations**: Import New table from JSON data.
- **OAuth2 Authentication**: Securely connect to your Zoho Analytics account across all regions (US, EU, IN, AU, CN, JP).

## License

[MIT](LICENSE)
